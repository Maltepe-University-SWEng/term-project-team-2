# app.py
import os
import json
import torch
from flask import Flask, render_template, jsonify
from transformers import AutoTokenizer, AutoModelForCausalLM
from huggingface_hub import login

app = Flask(__name__)

# 1) Hugging Face login
login(token=os.environ.get("HF_TOKEN", "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"))

# 2) Model & Tokenizer yükle
model_dir = "fikra-turkish-gpt2"
tokenizer = AutoTokenizer.from_pretrained(model_dir)
model     = AutoModelForCausalLM.from_pretrained(model_dir)
model.eval()

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/generate")
def generate():
    # Prompt öneki kaldırılmadan veriliyor ama dönerken kırpacağız
    prompt = "<|fıkra|>\n"
    inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
    out = model.generate(
        **inputs,
        max_new_tokens=200,
        do_sample=True,
        temperature=1.0,
        top_p=0.95,
        repetition_penalty=1.2,
    )
    text = tokenizer.decode(out[0], skip_special_tokens=True)
    # Eğer çıktı başında önek varsa sil
    prefix = "<|fıkra|>"
    if text.startswith(prefix):
        text = text[len(prefix):].lstrip(" \n")
    return jsonify({"fıkra": text})

if __name__ == "__main__":
    # port ve debug istediğin gibi ayarlanabilir
    app.run(host="0.0.0.0", port=5000, debug=True)
